package com.spring.admin.client.bootadminclient;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BootAdminClientApplicationTests {

	@Test
	public void contextLoads() {
	}

}
