package com.packt.springhighperformance.ch2.bankingapp.service;

public interface CustomerService {
	
	public void showCustomerAccountBalance();	

}
