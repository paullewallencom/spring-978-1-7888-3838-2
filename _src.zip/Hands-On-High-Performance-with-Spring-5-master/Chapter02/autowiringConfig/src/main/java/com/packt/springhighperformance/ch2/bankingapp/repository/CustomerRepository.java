package com.packt.springhighperformance.ch2.bankingapp.repository;

public interface CustomerRepository {

}
