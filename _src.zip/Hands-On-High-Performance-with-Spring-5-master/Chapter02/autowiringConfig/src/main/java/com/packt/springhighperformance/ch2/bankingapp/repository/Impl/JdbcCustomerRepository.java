package com.packt.springhighperformance.ch2.bankingapp.repository.Impl;

import org.springframework.stereotype.Repository;

import com.packt.springhighperformance.ch2.bankingapp.repository.CustomerRepository;
@Repository
public class JdbcCustomerRepository implements CustomerRepository {

}
