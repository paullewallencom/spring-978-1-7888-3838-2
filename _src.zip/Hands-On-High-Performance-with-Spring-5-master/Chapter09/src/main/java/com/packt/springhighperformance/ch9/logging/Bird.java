package com.packt.springhighperformance.ch9.logging;

public class Bird {

	public static void fly() {

	}

}
