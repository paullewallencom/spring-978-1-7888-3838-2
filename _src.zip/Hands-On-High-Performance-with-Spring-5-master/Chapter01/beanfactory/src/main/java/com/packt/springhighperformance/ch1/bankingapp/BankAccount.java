package com.packt.springhighperformance.ch1.bankingapp;

public class BankAccount {
	private String accountType;

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountType() {
		return this.accountType;
	}
}
