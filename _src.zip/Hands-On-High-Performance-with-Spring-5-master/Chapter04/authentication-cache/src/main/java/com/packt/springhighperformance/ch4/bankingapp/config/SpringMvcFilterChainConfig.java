package com.packt.springhighperformance.ch4.bankingapp.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringMvcFilterChainConfig extends AbstractSecurityWebApplicationInitializer {

    public SpringMvcFilterChainConfig() {
        super();
    }
}
