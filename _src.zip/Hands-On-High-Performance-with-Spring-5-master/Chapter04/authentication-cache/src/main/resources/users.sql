--user: cust001
--password: Test@123
INSERT INTO users(username, password, enabled) VALUES ('cust001', '$2a$10$P.2FmSPSL6nt7BQmAyWhv.Z2g5Gy0jMDcHpA6UlfEmgMKgz2yL4Pu', true);

--user: manager001
--password: Test@123
INSERT INTO users(username, password, enabled) VALUES ('manager001', '$2a$10$P.2FmSPSL6nt7BQmAyWhv.Z2g5Gy0jMDcHpA6UlfEmgMKgz2yL4Pu', true);