-- users' authorities                                                     
INSERT INTO authorities(username, authority) VALUES ('cust001', 'USER'); 
INSERT INTO authorities(username, authority) VALUES ('manager001', 'USER');
INSERT INTO authorities(username, authority) VALUES ('manager001', 'ADMIN');