package com.springhighperformance.jmx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleJmxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleJmxApplication.class, args);
	}
}
